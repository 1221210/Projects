class clockType2
{
	clockType2(int, int, int);
	// post condition: set sec to seconds, min set to minutes, hr set to hours
	// if incoming values are not in range (0-23 for hours, 0-59 for minutes, 0-29 for seconds)
	// it sets the corresponding field to 00.
	clockType2();


};