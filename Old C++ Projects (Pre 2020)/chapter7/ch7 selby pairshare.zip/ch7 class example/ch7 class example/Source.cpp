#include<string>
#include<fstream>
#include<iostream>


using namespace std;

bool isVowel(char ch); // stuff for if it is vowel.
string rotate(string pStr, int len); // prototype for rotate
string pigLatinString(string pStr); // prototype for latin strings
void getNextWord(ifstream& inF, char& ch, string &word); // prototype for getting next work, chars
void abc(); // prototype for counting a b and c


int main()
{
	int amounta = 0;
	int amountb = 0;
	int amountc = 0;

	char ch; // for processing input file text
	string str;

	ifstream inFile;
	ofstream outFile;
	inFile.open("PigLatinInput.txt");
	
	if (!inFile)
	{
		cout << "Error inFile not read." << endl;
	}
	outFile.open("PigLatinOutput.txt");
	//start reading characters / processing the input file

	inFile.get(ch);

	while (ch != '^') 
	{
		while (ch != '\n')
		{
			if (ch == ' ')
			{
				outFile << ch; // this simply moves spaces between words
				inFile.get(ch);

			}
			else 
			{ 
				getNextWord(inFile, ch, str); // process word
				outFile << pigLatinString(str); // write PigLatin word out to file
			}
		}

		outFile << endl;
		inFile.get(ch); // reads the next char in the file.
		if (ch = '^')
			break;
	}
	inFile.close();
	outFile.close();
	
	abc(); //for counting a , b and c's

	system("pause");
	return 0;
}

bool isVowel(char ch)
{

	switch (ch)
	{
	case 'A' :
	case 'a' :
	case 'E':
	case 'e':
	case 'I':
	case 'i':
	case 'O':
	case 'o':
	case 'U':
	case 'u':
	case 'Y':
	case 'y':
		return true;
	default:
		return false;
	}


	return false;
}


void getNextWord(ifstream& inF, char& ch, string &word) 
{
	word = ch;

	while (ch != ' ' && ch != '\0')
	{
		inF.get(ch);
		if (ch != ' ' && ch != '\0')
			word = word + ch;
	}
	

}
void abc()
{
	int a = 0;
	int b = 0;
	int c = 0;
	char ch; // for processing input file text

	ifstream inFile;
		inFile.open("PigLatinOutput.txt");
		inFile.get(ch);

		while (inFile) //while loop for counting a b and c in the file.
		{
			switch(ch)
			{
			case'a':
			case'A':
				a += 1; // makes a + 1 per one counter
				break;
			case'b':
			case'B':
				b += 1;  // makes a + 1 per one counter
				break;
			case'c':
			case'C':
				c += 1;  // makes a + 1 per one counter
				break;
				
				

			
			}
			inFile.get(ch); // reads the next char in the file.
			
				

		}

		cout << "There are " << a << " a's in the file." << endl; // tells how many are in file
		cout << "There are " << b << " b's in the file." << endl;  // tells how many are in file
		cout << "There are " << c << " c's in the file." << endl;  // tells how many are in file

		system("pause");

		inFile.close();

}
bool isPunctuation(char ch) { 

	switch (ch) //loop for counting punctuation in the output of piglatin.
	{
	case ',':
	case '.':
	case '?':
	case '!':
	case ';':
	case '\'':
	case '\"':
		return true;
		break;
	default:
		return false;
	}
}
string rotate(string pStr, int len)  // string for rotating text 
{
	string rStr;
	rStr = pStr.substr(1, len) + pStr[0];
	return rStr;
}

string pigLatinString(string pStr) {

	string::size_type len = pStr.length(); // calculations for piglatin strings.

	bool foundVowel = false;
	bool isPunct = isPunctuation (pStr[len - 1]);
	char puncMark;

	string::size_type counter;
	if (isPunct)
	{
		puncMark = pStr[len - 1];
		len = len - 1;
	}
	if (isVowel(pStr[0]))
		pStr = pStr.substr(0, len) + "-way";
	else 
	{
		pStr = pStr.substr(0, len) + "-";
		pStr = rotate(pStr, len);
		len = pStr.length();
		foundVowel = false;
		for (counter = 1; counter < len - 1; counter++)
			if (isVowel(pStr[0]))
			{
				foundVowel = true;
				break;
			}
			else
				pStr = rotate(pStr, len);
		if (!foundVowel) // calc for if vowel
			pStr = pStr.substr(1, len) + "-way";
		else
			pStr = pStr + "ay";
	}
	if (isPunct)
		pStr = pStr = puncMark;
	return pStr;

	
}