# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise: Problem 1.3
# Brief Description: Displays Designated Pattern from Book

print("FFFFFFF    U     U    NN      NN")
print("FF         U     U    NNN     NN")
print("FFFFFFF    U     U    NN  N   NN")
print("FF          U   U     NN    N NN")
print("FF           UUU      NN     NNN")

