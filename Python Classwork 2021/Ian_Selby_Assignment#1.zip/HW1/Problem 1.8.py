# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise: Problem 1.8
# Brief Description: Prints area and perimeter of a circle

# assign a value to radius
radius = 5.5  # radius is now equal to 5.5

# Compute Area // note ** followed by number is basically 5.5^x
area = radius ** 2 * 3.14159

# Display Result Area
print("The area for the given radius of:", radius, " is: ", area)

# Compute and display perimeter
perimeter = 2 * radius * 3.14159
print("The perimeter for the given radius of:", radius, " is: ", perimeter)
