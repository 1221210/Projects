# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise: Problem 1.4
# Brief Description: Prints a "table" from the book

print("a      a^2     a^3")
print("1      1       1")
print("2      4       8")
print("3      9       27")
print("4      16      64")