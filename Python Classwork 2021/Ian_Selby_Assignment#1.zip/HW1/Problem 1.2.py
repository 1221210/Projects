# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise: Problem 1.2
# Brief Description: Displays messages 5 times

num = 5
for x in range(num):  # for loop prints given text 5 times, or whatever num is set to
    print("Welcome to Python.")


