# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise: Problem 1.5
# Brief Description: Computes a given expression: to get answer 0.839285...

answer = (9.5 * 4.5 - 2.5 * 3) / (45.5 - 3.5)
print("The answer is: ", answer)