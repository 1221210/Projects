# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise: Problem 1.1
# Brief Description: Displays 3 messages
print("Welcome to Python.")
print("Welcome to Computer Science.")
print("Programing is fun.")
