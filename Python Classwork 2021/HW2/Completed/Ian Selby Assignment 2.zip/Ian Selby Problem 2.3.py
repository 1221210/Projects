# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise: 2.3 Feet to Meters converter

# User input
feet = eval(input("please enter the amount of feet you want to convert into meters: "))

# Calculations
meter = feet * 0.305

# print results
print(f"{feet} feet is {meter} meters.")