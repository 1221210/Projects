# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise: 2.4 Pound to Kilograms

# User input
pounds = eval(input("please enter the amount of pounds you want to convert into kilograms: "))

# calculations
kilograms = pounds * 0.454

# result output
print(f"{pounds} lbs is {kilograms} Kg.")