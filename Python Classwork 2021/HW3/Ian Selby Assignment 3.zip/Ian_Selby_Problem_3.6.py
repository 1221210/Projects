# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise:  Chapter 3.6

# Prompt user for ASCII code (ints 0 - 127)
ASCII = eval(input("Enter a ASCII code: "))

# Print resulting code
print(f"The ASCII code is: {chr(ASCII)}")



