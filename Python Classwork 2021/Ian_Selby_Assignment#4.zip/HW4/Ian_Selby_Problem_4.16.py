# cs1030
# name: Ian Selby
# 700720666
# Assignment / Exercise:  Chapter 4.16

import random  # import random for the choice of letter

alphabet = ['A', 'B', 'C', 'D', 'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P', 'Q', 'R', 'S', 'T', 'U',
            'V', 'W', 'X', 'Y', 'Z']
# print(alphabet) # testing variable
randLetter = random.choice(alphabet)

# print letter
print(randLetter)
