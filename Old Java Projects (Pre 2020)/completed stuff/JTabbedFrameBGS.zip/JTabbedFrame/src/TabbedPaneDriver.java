import javax.swing.JFrame;
import javax.swing.JTabbedPane;

public class TabbedPaneDriver {

	public static void main(String[] args)
	{
		JTabbedPaneFrame jtp = new JTabbedPaneFrame();
		jtp.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		jtp.setSize(250,200);
		jtp.setVisible(true);
		
		
	}

}
