package application;

// Main App class that loads and displays painter GUI
import javafx.application.Application;
import javafx.fxml.FXMLLoader;
import javafx.stage.Stage;
import javafx.scene.Scene;
import javafx.scene.Parent;;


public class Painter extends Application {
	@Override
	public void start(Stage stage) throws Exception {
	Parent root = 
		FXMLLoader.load(getClass().getResource("Painter (1).fxml"));
	
	
	Scene scene = new Scene(root); //attach scene graph to scene
	stage.setTitle("Painter"); // displayed in window's title bar
	stage.setScene(scene);// attach scene to stage
	stage.show();//displays the stage
	
	}
	
	public static void main(String[] args) {
		// create a painter obj and calls start method
		launch(args);
	}
}