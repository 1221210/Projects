// Ian Selby 700720666
#include <stdio.h>
int main(void)
{
// variable declaration
	int age;
	int year;
	int days;
	year = 365;
	age = 22;
	days = age * year;

// print age in years and days
	printf("User age in years is: %d\n", age );
	printf("User's age in days is: %d\n", days);
	
	return 0;
}
