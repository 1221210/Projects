// Ian Selby 700720666
#include<stdio.h>
int main(void)
{
	// variable definition and declarations
	int toes;
	toes = 10;
	int toesx2;
	toesx2 = toes * 2;
	int toessqr;
	toessqr = toes * toes;
	// variable print statement
	printf("You have %d toes. When doubled it is : %d , and when squared it is %d\n", toes, toesx2, toessqr);
}
